Visual C++ 2015 redistributable is required.

You need to install a fairly recent driver for your GPU. You can do this via
Windows Update. This works well for the integrated Intel GPU, but for AMD and
Nvidia cards downloading the driver from their website is usually better.

Use "./ElkoAlenka" to launch the program from command line or double-click.

Use --help to get a list of all the available options.

